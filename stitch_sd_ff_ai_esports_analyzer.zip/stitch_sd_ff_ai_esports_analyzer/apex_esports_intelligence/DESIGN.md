---
name: Apex Esports Intelligence
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#93ccff'
  on-secondary: '#003351'
  secondary-container: '#3198dc'
  on-secondary-container: '#002c47'
  tertiary: '#56e5a9'
  on-tertiary: '#003824'
  tertiary-container: '#30c88f'
  on-tertiary-container: '#004e34'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Chivo
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Chivo
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Chivo
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.04em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style
The design system establishes a high-performance, analytical environment engineered specifically for competitive Free Fire athletes, coaches, and tactical analysts. The aesthetic fuses premium modern minimalism with an aggressive, technical esports edge—evoking the surgical precision of an advanced military telemetry HUD crossed with the clean utility of professional developer tools.

### Visual Style
- **Technical Minimalism & Tactical Depth:** The interface discards chaotic RGB gamer tropes in favor of an elite, focus-driven dark canvas. Dense, readable metric clusters coexist with intentional negative space.
- **Atmospheric Edge:** High-contrast tactical telemetry, crisp border definitions (subtle ghost outlines), and low-glow electric cyan focal points prioritize critical performance indicators (headshot ratios, recoil resets, drop-zone heatmaps, and rotation timing).
- **Jetpack Compose Native Cadence:** Engineered natively around Android modern UI guidelines, utilizing rigid mathematical spacing, fluid state transitions, reactive micro-surfaces, and clear navigational targets tailored for one-handed and thumb-zone thumb-reach ergonomics.

## Colors
The color architecture relies on a controlled, low-luminance substrate paired with luminous, semantic indicators designed to minimize eye strain during long analytical debriefs while maintaining instantaneous legibility.

### Surface System
- **Canvas Base:** `#0B0F17` (Deep Obsidian Navy) provides maximum contrast and OLED battery efficiency.
- **Surface Elevation 1 (Containers/Nav):** `#111827` (Charcoal Slate) creates primary visual segmentation.
- **Surface Elevation 2 (Cards/Widgets):** `#1E293B` (Structured Slate) isolates actionable analytical cards.
- **Surface Elevation 3 (Overlays/Popovers):** `#334155` (Subtle Interactive Highlight).

### Key Accents & Semantics
- **Primary Tactical Cyan (`#38BDF8`):** Serves as the primary analytical signal, AI debrief indicator, active states, and focal metrics.
- **Secondary Deep Cyan (`#0284C7`):** Powers key interactive states, pressed fills, and selected indicator tracks.
- **Positive / Improvement (`#10B981` Emerald):** Quantifies climbing performance vectors (e.g., +8.4% K/D ratio, positive crosshair placement delta).
- **Negative / Decline (`#F43F5E` Rose):** Alerts to mechanical or tactical regression (e.g., misjudged safe-zone rotation timing, excessive death-to-gloo-wall latency).
- **Warning / Calibration (`#F59E0B` Amber):** Denotes volatile tactical variations, sub-optimal loot timings, and AI calibration needs.
- **Text System:** Primary text anchors at `#F8FAFC` (Crisp Chalk), with secondary metric subtitles and inactive states at `#94A3B8` (Muted Slate).

## Typography
The typographic hierarchy leverages **Space Grotesk** for numerical dashboards, metrics, tactical labels, and headers, and **Chivo** for sustained analytical explanations and coach feedback.

- **Space Grotesk** introduces structural geometry with condensed mechanical apexes, infusing a digital telemetry aesthetic that mirrors esports scoreboards without losing readability.
- **Chivo** delivers utilitarian clarity in high-density paragraphs (match timelines, tactical guidance, patch meta breakdowns).
- All labels and sub-metric titles employ uppercase letter-spacing (`0.04em` to `0.08em`) to enforce military-grade analytical division.
- Tabular figures (`font-variant-numeric: tabular-nums`) must be enabled globally across all analytical data grids to ensure column stability during live data streaming.

## Layout & Spacing
Designed from the mobile canvas up, the layout optimizes viewport density for Android devices while ensuring modular scalability for tablets and foldables.

### Layout Mechanics
- **Mobile Grid:** Fluid single-column layout strictly adhering to a 4-column sub-grid with an outer margin of `16px` (`margin`) and gutter of `16px` (`gutter`).
- **Vertical Grid Rhythm:** 4dp incremental spacing model. Micro gaps use `space-xs` (4dp) and `space-sm` (8dp), component internals utilize `space-md` (12dp) and `space-lg` (16dp), while structural card separation enforces `space-xl` (24dp).
- **Navigation Safety:** Bottom screen allocations reserve an explicit 80dp container zone plus system navigation bar padding to prevent touch collisions with Android 10+ edge gestures.
- **Reflow Boundaries:** Screen widths above 600dp (Foldables/Tablets) automatically reflow single-column statistical feeds into an asymmetric 8-column split: 5 columns for match visualizer/heatmap, 3 columns for real-time AI critique modules.

## Elevation & Depth
Elevation is defined through tactical tonal stacking and thin boundary borders, rather than heavy skeuomorphic cast shadows, keeping the interface minimal and performant.

### Layer Stacking Model
1. **Root Bed (`#0B0F17`):** The ground baseline.
2. **Elevated Containers (`#111827`):** Background grouping modules framed by a 1px ghost border of `rgba(255, 255, 255, 0.05)`.
3. **Card & Metric Widgets (`#1E293B`):** Raised interactive data blocks framed by a 1px border of `rgba(148, 163, 184, 0.12)`. When active or focused, the border transitions to `rgba(56, 189, 248, 0.4)`.
4. **Modal Overlays & Drawers (`#1E293B` with blur):** Floating system interactions feature `backdrop-filter: blur(16px)` and an ambient, low-spread drop shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.6)`.

### Tactical Glows
Critical AI breakthrough notifications or high-tier rank badges feature a restrained radial glow: an inner shadow or soft halo of `0 0 20px rgba(56, 189, 248, 0.15)`. No ambient shadows are applied to plain text or standard data cards.

## Shapes
The design system adopts a controlled, geometric softness (`roundedness: 1`). Soft bevels preserve the crisp, tactical identity of competitive shooter software without resorting to blunt or completely unstyled brutalism.

- **Micro Components (Badges, Chips, Indicators):** 4dp corner radius (`rounded-xs`/`rounded-sm`).
- **Core Components (Cards, Inputs, Banners):** 8dp corner radius (`rounded-md`/`rounded-lg`).
- **Floating Modals & Sheets:** Top edges utilize 12dp corner radius (`rounded-xl`).
- **Precision Data Tags:** Key delta pills (+14% HS Rate) may utilize chamfer-like 4dp radius to reinforce industrial hardware styling. Full circular pills are restricted solely to icon-only action triggers and small avatar badges.

## Components

### Buttons
- **Primary AI Action Button:** Background `#38BDF8`, foreground text `#0B0F17` (bold `Space Grotesk`). Height: 48dp. Corner radius: 8dp. On press: surface deepens to `#0284C7`.
- **Secondary Ghost Action:** Background transparent, border 1px solid `rgba(56, 189, 248, 0.3)`, text `#38BDF8`.
- **Danger/Decline Button:** Background `rgba(244, 63, 94, 0.1)`, border 1px solid `rgba(244, 63, 94, 0.3)`, text `#F43F5E`.

### Cards & Statistical Widgets
- **Data Card Archetype:** Background `#1E293B`, 1px border `rgba(148, 163, 184, 0.08)`, internal padding `space-lg` (16dp).
- **Telemetry Card:** Features a two-tiered header: sub-label in uppercase muted text (`label-sm`, `#94A3B8`) followed by large tabular metric figures (`headline-lg`, `#F8FAFC`). Includes an inline micro-trend indicator (e.g., an emerald badge `#10B981` indicating upward trajectory).

### Chips & Filter Tabs
- **Filter Chips:** Height 32dp. Default background `#111827`, border 1px `rgba(255, 255, 255, 0.08)`, text `#94A3B8`.
- **Selected State:** Background `rgba(56, 189, 248, 0.12)`, border 1px `#38BDF8`, text `#38BDF8`.

### Input Fields
- **Search & Parameter Input:** Container background `#111827`, border 1px `rgba(148, 163, 184, 0.2)`. Placeholder text `#94A3B8`. On focus: border shifts to `#38BDF8` with a subtle 2px outer glow (`rgba(56, 189, 248, 0.25)`).

### Selection Controls (Checkboxes & Radios)
- **Checkboxes & Radios:** Unselected: 2dp outline in `#94A3B8`, background transparent. Selected: `#38BDF8` fill with `#0B0F17` internal glyph. Checkbox corner radius is 2dp; radio is full circle.

### Bottom Navigation Bar (5 Destinations)
- **Destinations:** Home, Analyze, Training, Meta, Profile.
- **Container Specs:** Fixed 64dp bar height (excluding Android navigation inset) anchored above `#0B0F17`. Surface fill `#111827` with 1px top border `rgba(255, 255, 255, 0.08)`.
- **Icon & Label States:**
  - *Inactive:* Icon 24dp at `#94A3B8`, label `label-sm` at `#94A3B8`.
  - *Active:* Icon and label illuminated with `#38BDF8`. A 3dp horizontal electric cyan marker is centered 4dp below the selected destination label.

### Specialized AI Component: Coach Feedback Callout
- Encapsulated alert box with an asymmetric left-border accent (3dp solid `#38BDF8` or `#10B981`). Background tinted at `rgba(2, 132, 199, 0.06)`, delivering AI strategic advice alongside weapon accuracy delta charts.